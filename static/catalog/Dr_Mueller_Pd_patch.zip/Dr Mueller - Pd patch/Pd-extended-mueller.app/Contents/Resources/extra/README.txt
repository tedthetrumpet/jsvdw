This collection of abstraction is dedicated for data treatment using pure data.
It provide basic object for constant rate data flow treatement.
They are designed to be used with La kitchen sensors interfaces (Kroonde or Toaster).
but can feet other needs.

a help file is available for each object. 
You nead zexy and cyclone to be able to load this abstractions.

This collection of object were made by Charles Verron for La kitchen (march 2004)
question about it : cyrille.henry@la-kitchen.fr

