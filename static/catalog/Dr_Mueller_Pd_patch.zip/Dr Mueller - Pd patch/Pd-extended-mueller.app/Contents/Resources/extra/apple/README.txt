
The 'apple' library supports specific hardware features of Apple computers.
It was derived from a bunch of information online:

http://linux.derkeiler.com/Mailing-Lists/Kernel/2008-01/msg11050.html
http://www.anyma.ch/2009/research/multitouch-external-for-maxmsp/
