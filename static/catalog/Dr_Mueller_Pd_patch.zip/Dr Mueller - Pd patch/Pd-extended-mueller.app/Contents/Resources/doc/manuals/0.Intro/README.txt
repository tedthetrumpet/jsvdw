
This tutorial came out of the PDDP project:

http://puredata.info/dev/pddp

Contributors include (in alphabetical order):

Alexandre Castonguay
Aymeric Mansoux
Ben Bogart <ben@ekran.org>
Frank Barknecht
Gregorio García Karman <ggkarman@airtel.net>
Hans-Christoph Steiner <hans@at.or.at>
Jerome Abel
Koray Tahiroglu
Malte Steiner
Max Neupert
Miller Puckette <msp@crca.ucsd.edu>
Thomas Musil <musil@iem.at>
