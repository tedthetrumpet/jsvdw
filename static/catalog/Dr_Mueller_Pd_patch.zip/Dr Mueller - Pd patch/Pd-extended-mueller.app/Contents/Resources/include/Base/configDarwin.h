/* Base/configDarwin.h.  Generated from configDarwin.h.in by configure.  */

/* font rendering */
#define HAVE_LIBFTGL 1

/* image loading / saving */
/* #undef HAVE_LIBMAGICKPLUSPLUS */
/* #undef HAVE_LIBGMERLIN_AVDEC */


/* Pd header files */ 
/* #undef HAVE_S_STUFF_H */

/* types, structures, compiler characteristics, ... */
#define SIZEOF_VOID_P 4
#define SIZEOF_UNSIGNED_INT 4

/* image analysis */
/* #undef HAVE_ARTOOLKIT */
