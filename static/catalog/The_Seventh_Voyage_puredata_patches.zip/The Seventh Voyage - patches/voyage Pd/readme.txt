When installing the patch, make sure to copy the entire contents of the folder 'voyage Pd' exactly as is, complete with the folder called 'lib' and all the files in it.

Instructions for installing the correct version of Pd and the xsample library are included with the score.